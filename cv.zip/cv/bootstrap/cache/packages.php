<?php return array (
  'barryvdh/laravel-dompdf' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\DomPDF\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Pdf' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
      'PDF' => 'Barryvdh\\DomPDF\\Facade\\Pdf',
    ),
  ),
  'barryvdh/laravel-translation-manager' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\TranslationManager\\ManagerServiceProvider',
    ),
  ),
  'encore/laravel-admin' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\AdminServiceProvider',
    ),
    'aliases' => 
    array (
      'Admin' => 'Encore\\Admin\\Facades\\Admin',
    ),
  ),
  'fruitcake/laravel-cors' => 
  array (
    'providers' => 
    array (
      0 => 'Fruitcake\\Cors\\CorsServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'irisvn/media-manager' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Media\\MediaServiceProvider',
    ),
  ),
  'jackiedo/cart' => 
  array (
    'providers' => 
    array (
      0 => 'Jackiedo\\Cart\\CartServiceProvider',
    ),
    'aliases' => 
    array (
      'Cart' => 'Jackiedo\\Cart\\Facades\\Cart',
    ),
  ),
  'laravel-admin-ext/chartjs' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Chartjs\\ChartjsServiceProvider',
    ),
  ),
  'laravel-admin-ext/grid-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\GridSortable\\GridSortableServiceProvider',
    ),
  ),
  'laravel-admin-ext/helpers' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Helpers\\HelpersServiceProvider',
    ),
  ),
  'laravel-admin-ext/log-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\LogViewer\\LogViewerServiceProvider',
    ),
  ),
  'laravel-admin-ext/scheduling' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Scheduling\\SchedulingServiceProvider',
    ),
  ),
  'laravel-admin-ext/summernote' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Summernote\\SummernoteServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
  ),
);