<div data-elementor-type="footer" data-elementor-id="55" class="elementor elementor-55 elementor-location-footer"
     data-elementor-post-type="elementor_library">
    <section data-particle_enable="false" data-particle-mobile-disabled="false"
             class="elementor-section elementor-top-section elementor-element elementor-element-12a97f0c elementor-section-boxed elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
             data-id="12a97f0c" data-element_type="section"
             data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
        <div class="elementor-container elementor-column-gap-no">
            <div
                class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e9327f2 exad-glass-effect-no exad-sticky-section-no"
                data-id="e9327f2" data-element_type="column">
                <div class="elementor-widget-wrap elementor-element-populated">
                    <section data-particle_enable="false" data-particle-mobile-disabled="false"
                             class="elementor-section elementor-inner-section elementor-element elementor-element-51fb5c41 elementor-section-full_width elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
                             data-id="51fb5c41" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div
                                class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-c365d19 exad-glass-effect-no exad-sticky-section-no"
                                data-id="c365d19" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div
                                        class="elementor-element elementor-element-9e7b75c exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                        data-id="9e7b75c" data-element_type="widget"
                                        data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h5 class="elementor-heading-title elementor-size-default">Nfbaitc</h5>
                                        </div>
                                    </div>
                                    <div
                                        class="elementor-element elementor-element-6d840483 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                        data-id="6d840483" data-element_type="widget"
                                        data-widget_type="text-editor.default">
                                        <div class="elementor-widget-container">
                                            Create your CV online with our CV maker in just a few minutes
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-34f4ff73 exad-glass-effect-no exad-sticky-section-no"
                                data-id="34f4ff73" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div
                                        class="elementor-element elementor-element-349a6188 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                        data-id="349a6188" data-element_type="widget"
                                        data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h5 class="elementor-heading-title elementor-size-default">Quick Links</h5>
                                        </div>
                                    </div>
                                    <div
                                        class="elementor-element elementor-element-21a1926a elementor-icon-list--layout-traditional elementor-list-item-link-full_width exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-icon-list"
                                        data-id="21a1926a" data-element_type="widget"
                                        data-widget_type="icon-list.default">
                                        <div class="elementor-widget-container">
                                            <ul class="elementor-icon-list-items">
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">
												<span class="elementor-icon-list-icon">
							                    <i aria-hidden="true" class="fas fa-caret-right"></i>
                                                </span>
                                                        <span class="elementor-icon-list-text">CV builder</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">
												<span class="elementor-icon-list-icon">
							                    <i aria-hidden="true" class="fas fa-caret-right"></i>
                                                </span>
                                                        <span class="elementor-icon-list-text">CV templates</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-622bfe79 exad-glass-effect-no exad-sticky-section-no"
                                data-id="622bfe79" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div
                                        class="elementor-element elementor-element-10830d8a exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                        data-id="10830d8a" data-element_type="widget"
                                        data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h5 class="elementor-heading-title elementor-size-default">Infomation</h5>
                                        </div>
                                    </div>
                                    <div
                                        class="elementor-element elementor-element-76b47e08 elementor-icon-list--layout-traditional elementor-list-item-link-full_width exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-icon-list"
                                        data-id="76b47e08" data-element_type="widget"
                                        data-widget_type="icon-list.default">
                                        <div class="elementor-widget-container">
                                            <ul class="elementor-icon-list-items">
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-caret-right"></i>						</span>
                                                        <span class="elementor-icon-list-text">About Us</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fas fa-caret-right"></i>						</span>
                                                        <span class="elementor-icon-list-text">Contact Us</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-6766fbc7 exad-glass-effect-no exad-sticky-section-no"
                                data-id="6766fbc7" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div
                                        class="elementor-element elementor-element-21d69c7b exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                        data-id="21d69c7b" data-element_type="widget"
                                        data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h5 class="elementor-heading-title elementor-size-default">Stay Tuned With
                                                Us</h5></div>
                                    </div>
                                    <div
                                        class="elementor-element elementor-element-4fa823b8 elementor-icon-list--layout-traditional elementor-list-item-link-full_width exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-icon-list"
                                        data-id="4fa823b8" data-element_type="widget"
                                        data-widget_type="icon-list.default">
                                        <div class="elementor-widget-container">
                                            <ul class="elementor-icon-list-items">
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-facebook-square"></i>						</span>
                                                        <span class="elementor-icon-list-text">Facebook</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-twitter-square"></i>						</span>
                                                        <span class="elementor-icon-list-text">Twitter</span>
                                                    </a>
                                                </li>
                                                <li class="elementor-icon-list-item">
                                                    <a href="#">

												<span class="elementor-icon-list-icon">
							<i aria-hidden="true" class="fab fa-linkedin"></i>						</span>
                                                        <span class="elementor-icon-list-text">LinkedIn</span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section data-particle_enable="false" data-particle-mobile-disabled="false"
                             class="elementor-section elementor-inner-section elementor-element elementor-element-4e889a10 elementor-section-full_width elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
                             data-id="4e889a10" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-no">
                            <div
                                class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1fe59556 exad-glass-effect-no exad-sticky-section-no"
                                data-id="1fe59556" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div
                                        class="elementor-element elementor-element-3d8c8892 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                        data-id="3d8c8892" data-element_type="widget"
                                        data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <span class="elementor-heading-title elementor-size-default">© 2023 Nfbatic, All Rights Reserved</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div
                                class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-2d592579 exad-glass-effect-no exad-sticky-section-no"
                                data-id="2d592579" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div
                                        class="elementor-element elementor-element-5b27a048 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                        data-id="5b27a048" data-element_type="widget"
                                        data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <span class="elementor-heading-title elementor-size-default">Terms and conditions | Privacy policy</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
</div>
