<div class="modal preview_cv_modal direction-ltr">
    <div class="modal-dialog modal-dialog-scrollable" style="overflow-y: auto;max-height: 100%;">
        <div class="modal_container" style="margin-top:0">
            <div class="modal-content" aria-modal="true" style="text-align: left">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i
                            class="fa fa-close" aria-hidden="true"></i></button>
                </div>
                <div  id="preview_cv_modal_content"></div>
            </div>
        </div>
    </div>
</div>
