<section data-particle_enable="false" data-particle-mobile-disabled="false"
         class="elementor-section elementor-top-section elementor-element elementor-element-5ad58134 elementor-section-boxed elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
         data-id="5ad58134" data-element_type="section"
         data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
    <div class="elementor-background-overlay"></div>
    <div class="elementor-container elementor-column-gap-default">
        <div
            class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-32a89e5d exad-glass-effect-no exad-sticky-section-no"
            data-id="32a89e5d" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div
                    class="elementor-element elementor-element-10e7641d elementor-view-stacked elementor-widget__width-auto elementor-absolute elementor-shape-circle exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-icon"
                    data-id="10e7641d" data-element_type="widget"
                    data-settings="{&quot;_position&quot;:&quot;absolute&quot;}"
                    data-widget_type="icon.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-icon-wrapper">
                            <div class="elementor-icon">
                                <i aria-hidden="true" class="remixicon ri-bank-card-fill"></i></div>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-element elementor-element-6c6c1a1b exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-image"
                    data-id="6c6c1a1b" data-element_type="widget" data-widget_type="image.default">
                    <div class="elementor-widget-container">
                        <img decoding="async" loading="lazy" width="800" height="575"
                             src="https://projects.datatime4it.com/chtml/wp-content/uploads/2023/09/resumes-templates.webp"
                             class="attachment-large size-large wp-image-160" alt=""
                             srcset="https://projects.datatime4it.com/chtml/wp-content/uploads/2023/09/resumes-templates.webp 922w, https://projects.datatime4it.com/chtml/wp-content/uploads/2023/09/resumes-templates-300x216.webp 300w, https://projects.datatime4it.com/chtml/wp-content/uploads/2023/09/resumes-templates-768x552.webp 768w"
                             sizes="(max-width: 800px) 100vw, 800px"></div>
                </div>
                <div
                    class="elementor-element elementor-element-4fe7137d elementor-widget__width-auto elementor-widget-mobile__width-inherit exad-glass-effect-yes e-transform exad-sticky-section-no elementor-widget elementor-widget-counter"
                    data-id="4fe7137d" data-element_type="widget"
                    data-settings="{&quot;_transform_translateY_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:-15,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateX_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_tablet&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]},&quot;_transform_translateY_effect_hover_mobile&quot;:{&quot;unit&quot;:&quot;px&quot;,&quot;size&quot;:&quot;&quot;,&quot;sizes&quot;:[]}}"
                    data-widget_type="counter.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-counter">
                            <div class="elementor-counter-number-wrapper">
                                <span class="elementor-counter-number-prefix"></span>
                                <span class="elementor-counter-number" data-duration="2000" data-to-value="50"
                                      data-from-value="0" data-delimiter=",">0</span>
                                <span class="elementor-counter-number-suffix">K</span>
                            </div>
                            <div class="elementor-counter-title">Templets</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-763a3a29 exad-glass-effect-no exad-sticky-section-no"
            data-id="763a3a29" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div
                    class="elementor-element elementor-element-37964b97 exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-heading"
                    data-id="37964b97" data-element_type="widget"
                    data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}"
                    data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h2 class="elementor-heading-title elementor-size-default">Online CV Creator</h2></div>
                </div>
                <div
                    class="elementor-element elementor-element-18c960b exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-heading"
                    data-id="18c960b" data-element_type="widget"
                    data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                    data-widget_type="heading.default">
                    <div class="elementor-widget-container">
                        <h3 class="elementor-heading-title elementor-size-default">Insert our pre-written CV
                            content
                        </h3></div>
                </div>
                <div
                    class="elementor-element elementor-element-719301a exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                    data-id="719301a" data-element_type="widget" data-widget_type="text-editor.default">
                    <div class="elementor-widget-container">
                        Creating a CV with the best online CV maker in the Saudi Arabia couldn&#8217;t be
                        easier.
                        Get inspiration on the go with CV examples for any industry, role, or experience level.
                        Pick
                        a stunning CV template &#8211; builder-checked and ready for download
                    </div>
                </div>
                <section data-particle_enable="false" data-particle-mobile-disabled="false"
                         class="elementor-section elementor-inner-section elementor-element elementor-element-11443253 elementor-section-boxed elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
                         data-id="11443253" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div
                            class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-1bfce8ad exad-glass-effect-no exad-sticky-section-no"
                            data-id="1bfce8ad" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-a3805ee elementor-align-left exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-button"
                                    data-id="a3805ee" data-element_type="widget"
                                    data-widget_type="button.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-button-wrapper">
                                            <a class="elementor-button elementor-button-link elementor-size-sm elementor-animation-float"
                                               href="https://projects.datatime4it.com/chtml/startcv/">
                                                        <span class="elementor-button-content-wrapper">
                                                        <span class="elementor-button-text">Start  Now</span>
		                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-cc5106a exad-glass-effect-no exad-sticky-section-no"
                            data-id="cc5106a" data-element_type="column">
                            <div class="elementor-widget-wrap">
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
