<section data-particle_enable="false" data-particle-mobile-disabled="false"
         class="elementor-section elementor-top-section elementor-element elementor-element-17eee75e elementor-section-boxed elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
         data-id="17eee75e" data-element_type="section"
         data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
    <div class="elementor-background-overlay"></div>
    <div class="elementor-container elementor-column-gap-no">
        <div
            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-7dcec61f exad-glass-effect-no exad-sticky-section-no"
            data-id="7dcec61f" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <section data-particle_enable="false" data-particle-mobile-disabled="false"
                         class="elementor-section elementor-inner-section elementor-element elementor-element-97e555d elementor-section-full_width elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
                         data-id="97e555d" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div
                            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-167aa819 exad-glass-effect-no exad-sticky-section-no"
                            data-id="167aa819" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-3da5d94a exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-heading"
                                    data-id="3da5d94a" data-element_type="widget"
                                    data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Lets Get
                                            Started</h2></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-287127a3 exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-heading"
                                    data-id="287127a3" data-element_type="widget"
                                    data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;,&quot;_animation_delay&quot;:200}"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h3 class="elementor-heading-title elementor-size-default">Create your
                                            CV in
                                            3 Steps</h3></div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-114a2776 exad-glass-effect-no exad-sticky-section-no"
                            data-id="114a2776" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <section data-particle_enable="false" data-particle-mobile-disabled="false"
                                         class="elementor-section elementor-inner-section elementor-element elementor-element-6c6987b5 elementor-section-boxed elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
                                         data-id="6c6987b5" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div
                                            class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7b5e506 exad-glass-effect-no exad-sticky-section-no"
                                            data-id="7b5e506" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div
                                                    class="elementor-element elementor-element-65fd5d7b elementor-widget__width-initial exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-image"
                                                    data-id="65fd5d7b" data-element_type="widget"
                                                    data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;}"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img decoding="async"
                                                             src="https://projects.datatime4it.com/chtml/wp-content/uploads/elementor/thumbs/make-it-yours-qd2wpx17sh9dbj9gnsr0mosddi9hypff4vsv3is8w0.webp"
                                                             title="make-it-yours" alt="make-it-yours"
                                                             loading="lazy"></div>
                                                </div>
                                                <div
                                                    class="elementor-element elementor-element-55c60757 elementor-widget__width-initial exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-image"
                                                    data-id="55c60757" data-element_type="widget"
                                                    data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;,&quot;_animation_delay&quot;:100}"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img decoding="async"
                                                             src="https://projects.datatime4it.com/chtml/wp-content/uploads/elementor/thumbs/make-it-yours-qd2wpx17sh9dbj9gnsr0mosddi9hypff4vsv3is8w0.webp"
                                                             title="make-it-yours" alt="make-it-yours"
                                                             loading="lazy"></div>
                                                </div>
                                                <div
                                                    class="elementor-element elementor-element-5cb43c3c elementor-widget__width-initial exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-image"
                                                    data-id="5cb43c3c" data-element_type="widget"
                                                    data-settings="{&quot;_animation&quot;:&quot;fadeInRight&quot;,&quot;_animation_delay&quot;:200}"
                                                    data-widget_type="image.default">
                                                    <div class="elementor-widget-container">
                                                        <img decoding="async"
                                                             src="https://projects.datatime4it.com/chtml/wp-content/uploads/elementor/thumbs/make-it-yours-qd2wpx17sh9dbj9gnsr0mosddi9hypff4vsv3is8w0.webp"
                                                             title="make-it-yours" alt="make-it-yours"
                                                             loading="lazy"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div
                                            class="elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-530afafe exad-glass-effect-no exad-sticky-section-no"
                                            data-id="530afafe" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div
                                                    class="elementor-element elementor-element-15de41ba elementor-widget__width-auto exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-counter"
                                                    data-id="15de41ba" data-element_type="widget"
                                                    data-widget_type="counter.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-counter">
                                                            <div class="elementor-counter-number-wrapper">
                                                                    <span
                                                                        class="elementor-counter-number-prefix"></span>
                                                                <span class="elementor-counter-number"
                                                                      data-duration="2000" data-to-value="350"
                                                                      data-from-value="0"
                                                                      data-delimiter=",">0</span>
                                                                <span
                                                                    class="elementor-counter-number-suffix">K</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="elementor-element elementor-element-6a1f12c5 elementor-widget__width-auto exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                                    data-id="6a1f12c5" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h5 class="elementor-heading-title elementor-size-default">
                                                            +</h5></div>
                                                </div>
                                                <div
                                                    class="elementor-element elementor-element-3e3b40cb exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-heading"
                                                    data-id="3e3b40cb" data-element_type="widget"
                                                    data-widget_type="heading.default">
                                                    <div class="elementor-widget-container">
                                                        <h5 class="elementor-heading-title elementor-size-default">
                                                            People Trut Us</h5></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                        <div
                            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6e7416e9 exad-glass-effect-no exad-sticky-section-no"
                            data-id="6e7416e9" data-element_type="column">
                            <div class="elementor-widget-wrap">
                            </div>
                        </div>
                    </div>
                </section>
                <div
                    class="elementor-element elementor-element-1ae3b426 elementor-widget-divider--view-line_icon elementor-widget-divider--element-align-left elementor-widget__width-initial elementor-view-default exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-divider"
                    data-id="1ae3b426" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
                                <span class="elementor-divider-separator">
                                    <div class="elementor-icon elementor-divider__element">
                                        <i aria-hidden="true" class="fas fa-circle"></i>
                                        <i class="fa fa-eercast" aria-hidden="true"></i>
                                    </div>
                                </span>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-element elementor-element-7ffaf554 elementor-widget__width-initial elementor-hidden-tablet elementor-hidden-mobile elementor-widget-divider--view-line exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-divider"
                    data-id="7ffaf554" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-element elementor-element-796e8cfb elementor-widget__width-initial elementor-hidden-tablet elementor-hidden-mobile elementor-widget-divider--view-line exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-divider"
                    data-id="796e8cfb" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
			<span class="elementor-divider-separator">
						</span>
                        </div>
                    </div>
                </div>
                <div
                    class="elementor-element elementor-element-37a29a1e elementor-widget-divider--view-line_icon elementor-widget-divider--element-align-right elementor-widget__width-initial elementor-view-default exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-divider"
                    data-id="37a29a1e" data-element_type="widget" data-widget_type="divider.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-divider">
			<span class="elementor-divider-separator">
							<div class="elementor-icon elementor-divider__element">
					<i aria-hidden="true" class="fas fa-circle"></i>
</div>
						</span>
                        </div>
                    </div>
                </div>
                <section data-particle_enable="false" data-particle-mobile-disabled="false"
                         class="elementor-section elementor-inner-section elementor-element elementor-element-18679410 elementor-section-full_width elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
                         data-id="18679410" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-custom">
                        @foreach($steps as $step)
                        <div
                            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-65e8f9d1 exad-glass-effect-no exad-sticky-section-no"
                            data-id="65e8f9d1" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-684f9879 elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="684f9879" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">{{$step->order_column}}</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-ba9c826 elementor-position-top exad-sticky-section-no exad-glass-effect-no elementor-invisible elementor-widget elementor-widget-image-box"
                                    data-id="ba9c826" data-element_type="widget"
                                    data-settings="{&quot;_animation&quot;:&quot;fadeInUp&quot;}"
                                    data-widget_type="image-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-image-box-wrapper">
                                            <figure class="elementor-image-box-img">
                                                <img decoding="async"
                                                     loading="lazy"
                                                      width="384"
                                                      height="243"
                                                      src="{{asset('files/'.$step->image)}}"
                                                      class="elementor-animation-float attachment-full size-full wp-image-81" alt="">
                                            </figure>
                                            <div class="elementor-image-box-content">
                                                <h5 class="elementor-image-box-title">{{$step->{"title_".$lang } }}</h5>
                                                <p class="elementor-image-box-description">{{$step->{"description_".$lang } }}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @endforeach
                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
