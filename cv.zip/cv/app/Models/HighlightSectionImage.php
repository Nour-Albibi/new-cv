<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HighlightSectionImage extends Model
{
    use HasFactory;
    protected $fillable=['hero_section_id','image'];
}
