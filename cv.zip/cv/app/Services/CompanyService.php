<?php

namespace App\Services;

class CompanyService
{

}
