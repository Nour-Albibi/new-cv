<br>
<ul class="uleducation add-list"
    style="margin-top: 55px;list-style: none">
    <?php $__currentLoopData = $related_skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re_skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li style="margin-bottom: 10px;list-style: none !important;">
            <?php ($checkedClass=""); ?>






            <div class="skills_data <?php echo e($checkedClass, false); ?>" skill_id="<?php echo e($re_skill->id, false); ?>" skill_content="<?php echo e($re_skill->{"name_".$cv_lang}, false); ?>"
                 onclick="addSkillData('<?php echo e($re_skill->id, false); ?>','<?php echo e($re_skill->{"name_".$cv_lang}, false); ?>')" type="add"><span
                    class="add-remove"><i class="fas fa-plus-circle"></i></span> <?php echo e($re_skill->{"name_".$cv_lang}, false); ?>

            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/ajax/get_skills_suggestions.blade.php ENDPATH**/ ?>