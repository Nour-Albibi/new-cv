<?php $__env->startSection('title'); ?>
    Subscriptions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body  pt-0">
                <ul class="nav nav-tabs nav-tabs-custom mb-4">
                    <li class="nav-item">
                        <a class="nav-link fw-bold p-3 active" href="#">Subscription Managment</a>
                    </li>

                </ul>
                <div class="table-responsive">


                    <table class="table table-centered datatable dt-responsive nowrap " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead class="thead-light">
                            <tr>
                                <th style="width: 20px;">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="ordercheck">
                                        <label class="form-check-label" for="ordercheck">&nbsp;</label>
                                    </div>
                                </th>
                                <th>PLAN</th>
                                <th>price</th>
                                <th>Subscrip Date</th>
                                <th>Expire Date</th>
                                <th>Status	</th>



                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="ordercheck1">
                                        <label class="form-check-label" for="ordercheck1">&nbsp;</label>
                                    </div>
                                </td>
                                <td><a href="<?php echo e(route('customer.subscriptions.show',$subscription), false); ?>" class="text-dark fw-bold"><?php echo e($subscription->package->{"name_".$lang} ?? '', false); ?></a> </td>
                                <td><?php echo e($subscription->package->total_price, false); ?> SAR</td>
                                <td>
                                    <?php echo e($subscription->start_date, false); ?>

                                </td>
                                <td><?php echo e($subscription->end_date, false); ?></td>


                                <td>
                                    <div class=<?php if($subscription->status == '1'): ?>"badge badge-soft-success font-size-12">Paid</div>
                                    <?php else: ?>   "badge badge-soft-danger font-size-12">Expire</div>
                                    <?php endif; ?>
                                </td>
                                <td id="tooltip-container1">


                                </td>
                            </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/subscriptions/index.blade.php ENDPATH**/ ?>