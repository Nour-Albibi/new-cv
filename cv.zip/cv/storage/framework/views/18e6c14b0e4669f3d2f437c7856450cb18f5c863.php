<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e(__('CV'), false); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('cv-templates/cv2/css/cv2_pdf.css'), false); ?>" />
    <!--Custom CSS-->
    <style>
        .Home{
            background-color: <?php echo e($cv->template_color ?? "#0187de", false); ?>  !important;
        }
        .inner_contact_area{
            background-color: <?php echo e($cv->template_color ?? "#0187de", false); ?>  !important;
        }
        .col2{
            border-left:3px solid <?php echo e($cv->template_color ?? "#0187de", false); ?>  !important;
        }
        h5.section-title{
            color: <?php echo e($cv->template_color ?? "#0187de", false); ?>  !important;
        }
    </style>
</head>
<body>
<?php ($cv_lang=$cv->cv_language); ?>
<div class="Home">
    <div class="inner_home">
        <header>
            <div class="inner_header display-table header_table">
                <div class="table-cell header_info">
                    <h1 class="name">
                        <?php if($cv_lang=="en"): ?>
                            <?php echo e($cv->first_name.' '.$cv->surename, false); ?>

                        <?php else: ?>
                            <?php echo e($cv->first_name_ar.' '.$cv->surename_ar, false); ?>

                        <?php endif; ?>
                    </h1>
                    <?php if(!empty($cv->{"summary_content_".$cv_lang})): ?>
                        <p class="summary">
                            <?php echo $cv->{"summary_content_".$cv_lang}; ?>

                        </p>
                    <?php endif; ?>
                </div>
                <div class="table-cell">
                    <div class="">
                        <?php if(!empty($cv->image)): ?>
                            <img class="personal_image" src="<?php echo e(asset('files/uploads/'.$cv->image), false); ?>" width="116"
                                 height="116"
                                 loading="lazy"/>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </header>
        <div class="contact_area mt-40">
            <div class="inner_contact_area">
                <div class="display-table contact_table">
                    <div class="table-cell" style="width:38%;height:100%">
                        <div class="display-grid" style="">
                            <?php if(!empty($cv->email)): ?>
                                <div class="position_relative">
                                    <p class=" ml-5"><?php echo e($cv->email, false); ?></p>
                                </div>
                            <?php endif; ?>
                            <?php if(!empty($cv->phone)): ?>
                                <div class="position_relative mt-5">
                                    <p class="ml-5"><?php echo e($cv->phone, false); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="table-cell"
                         style="width:150px;border-left:1px solid #6cc1fa;border-right:1px solid #6cc1fa"></div>
                    <div class="table-cell" style="">
                        <?php if(!empty($cv->{"address_".$cv_lang })): ?>
                            <div class="position_relative ml-5">
                                <p class="ml-5" style="max-width:114px;">
                                    <?php echo e($cv->{"address_".$cv_lang }, false); ?>

                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="inner_content width100">
            <div class="" style="display:table">
                <div class="col1" style="display:table-cell;width:50%">
                    <?php if(count($cv->customer_cv_work_history)): ?>
                        <div class="experience-section section section-row">
                            <div class="col">
                                <h5 class="section-title text-left"><?php echo e(__('EXPERIENCE'), false); ?></h5>
                            </div>
                            <div class="col">
                                <?php $__currentLoopData = $cv->customer_cv_work_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="section-description mt-15 experience-item">
                                        <p><?php echo e(date("m-Y",strtotime($work->start_date)), false); ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($work->end_date)), false); ?></p>
                                        <p class="strong"
                                           style="max-width:285px"><?php echo e($work->{"job_title_".$cv_lang}, false); ?></p>
                                        <p class="strong"><?php echo e($work->{"employeer_".$cv_lang}, false); ?></p>
                                        <div class="description_area">
                                            <?php echo $work->{"experience_description_".$lang }; ?>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(count($cv->customer_cv_course)): ?>
                        <div class="education-section section section-row mt-30">
                            <div class="col">
                                <h5 class="section-title text-left"><?php echo e(__('Courses'), false); ?></h5>
                            </div>
                            <div class="col">
                                <?php $__currentLoopData = $cv->customer_cv_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div style="max-width:300px">
                                        <div class="section-description mt-15 education-item">
                                            <div style="display: flex">
                                                <p class="strong"><?php echo e(__('Course Name: '), false); ?> </p>
                                                <p><?php echo e($course->{"course_name_".$cv_lang}, false); ?>,
                                                    <?php echo e(date("m-Y",strtotime($course->start_date)), false); ?>

                                                    - <?php echo e(date("m-Y",strtotime($course->end_date)), false); ?>

                                                </p>
                                            </div>
                                            <div style="display: flex">
                                                <p class="strong"><?php echo e(__('Trainer: '), false); ?><?php echo e($course->{"trainer_".$cv_lang}, false); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                </div>
                <?php endif; ?>
                <div class="col2" style="display:table-cell;width:50%">
                    <?php if(count($cv->customer_cv_project)): ?>
                        <div class="experience-section section section-row">
                            <div class="col">
                                <h5 class="section-title text-left"><?php echo e(__('Projects'), false); ?></h5>
                            </div>
                            <div class="col">
                                <?php $__currentLoopData = $cv->customer_cv_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="section-description mt-15 experience-item">
                                        <div
                                            style="display:flex;margin-bottom: 4px;">
                                            <p class="strong" style="max-width:285px"><?php echo e(__("Project Name"), false); ?>

                                                :<?php echo e($project->{"project_name_".$cv_lang}, false); ?></p>
                                            <p class="strong"><?php if(!empty($project->start_date)): ?><?php echo e(date("m-Y",strtotime($project->start_date)), false); ?>  <?php endif; ?>
                                                <?php if(!empty($project->end_date)): ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($project->end_date)), false); ?> <?php endif; ?></p>
                                        </div>
                                        <div class="description_area">
                                        <p><?php echo e($project->{"description_".$cv_lang}, false); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(!empty($cv->{"skills_content_".$cv_lang})): ?>
                        <div class="education-section section section-row personal-info-section">
                            <div class="col">
                                <h5 class="section-title text-left"><?php echo e(__('Skills'), false); ?></h5>
                            </div>
                            <div class="col">
                                <div class="personal-info-description  mt-10">
                                    <div class="skills_area">
                                        <?php echo $cv->{"skills_content_".$cv_lang}; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(count($cv->customer_cv_education)): ?>
                        <div class="education-section section section-row mt-30">
                            <div class="col">
                                <h5 class="section-title text-left"><?php echo e(__('EDUCATION'), false); ?></h5>
                            </div>
                            <div class="col">
                                <?php $__currentLoopData = $cv->customer_cv_education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="section-description mt-15 education-item">
                                        <div style="display: flex">
                                            <p class="strong">BA (Hons) : </p>
                                            <p><?php echo e($edu->{"field_study_".$cv_lang}, false); ?>,
                                                <?php echo e(date("m-Y",strtotime($edu->start_date)), false); ?>

                                                - <?php echo e(date("m-Y",strtotime($edu->end_date)), false); ?>

                                            </p>
                                        </div>
                                        <div style="display: flex">
                                            <p class="strong"><?php echo e($edu->{"institution_name_".$cv_lang}, false); ?></p>
                                            <p>- <?php echo e($edu->{"city_".$cv_lang}, false); ?></p>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv-templates/cv2_pdf.blade.php ENDPATH**/ ?>