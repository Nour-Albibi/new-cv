<div class="row width100 mb86">
    <div class="form-group">

        <div class="input uploadContainer">
            <form class="box" action="<?php echo e(route('cv.upload'), false); ?>" method="post">
                <span class="inner_input"></span>
                <div class="box__input">
                    <img src="<?php if(!empty($addedItem)): ?><?php echo e(asset('files/uploads/'.$addedItem->model->image), false); ?><?php endif; ?>"  <?php if(empty($addedItem) || empty($addedItem->model->image)): ?> class="d-none" <?php endif; ?> id="uploaded_im" width="100" height="100"/>
                    <?php echo csrf_field(); ?>
                    <div class="upload_icon"></div>
                    <input class="box__file" type="file" name="image" id="file"
                           data-multiple-caption="{count} files selected"/>
                    <label class="file" for="file"><?php echo e(__('Choose a file or Drag it here to upload it'), false); ?></label>
                </div>
                <div class="box__uploading">Uploading…</div>
                <div class="box__success alert-success"><p><?php echo e(__('Uploaded Successfully'), false); ?></p></div>
                <div class="box__error">Error! <span></span>.</div>
            </form>
        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/components/cv/upload_image_field.blade.php ENDPATH**/ ?>