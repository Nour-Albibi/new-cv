<?php $__env->startSection('title'); ?>
    Viewed My CVs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="page-content-wrapper">

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <h5>Viewed MY CV</h5>
                            <div class="table-responsive">
                                <table class="table table-centered datatable dt-responsive nowrap " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                    <tr>

                                        <th scope="col"> CV Template</th>
                                        <th scope="col"> Company name</th>
                                        <th scope=""> How often</th>
                                        <th scope=""> date</th>

                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php $__currentLoopData = $cv->views()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td>

                                                <img src="<?php echo e(asset("files/".$view->cv->template->image), false); ?>" alt="" class=""
                                                style="width: 150px;">
                                            </td>
                                            <td><?php echo e($view->company->first_name.' '.$view->company->last_name, false); ?></td>
                                            <td>
                                                <?php echo e($view->cv->views, false); ?>

                                            </td>
                                            <td><?php echo e(date('d/m/Y', strtotime($view->cv->created_at)), false); ?></td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>


                        </div>
                    </div>
                </div>
            </div>

        </div>


    </div> <!-- container-fluid -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/cvs/viewdmyCV.blade.php ENDPATH**/ ?>