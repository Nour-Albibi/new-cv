<?php $__env->startSection('title','My latest cvs'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="page-content-wrapper">
            <div class="row">
                <div class="col-lg-8">
                    <?php if(count($customer_views)): ?>
                        <div class="card">
                            <div class="card-body  pt-0">
                                <ul class="nav nav-tabs nav-tabs-custom mb-4">
                                    <li class="nav-item">
                                        <a class="nav-link fw-bold p-3 active" href="#">Viewed MY CV </a>
                                    </li>

                                </ul>
                                <div class="table-responsive">
                                    <table class="table table-centered datatable dt-responsive nowrap "
                                           style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                        <thead class="thead-light">
                                        <tr>
                                            <th>CV Template</th>
                                            <th>Company Name</th>
                                            <th>how often</th>
                                            <th> Date</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $customer_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="exad-card left text_on_image yes"
                                                         style="overflow:hidden;max-width:265px;max-height:350px;">
                                                        <div class="exad-card-thumb">
                                                            <?php $cv=$view->cv; ?>
                                                            <?php echo $__env->make('components.cv.cv_template_'.$cv->template->file_name.'_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo e($view->company->company_name, false); ?></td>
                                                <td>
                                                    <div
                                                        class="badge badge-soft-success font-size-12"> <?php echo e($view->how_often, false); ?></div>
                                                </td>
                                                <td><?php echo e(date('d/m/Y', strtotime($view->cv->created_at)), false); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="card">
                            <div class="card-body">
                                <h5>My latest cvs</h5>
                                <div class="table-responsive">
                                    <table class="table table-centered table-nowrap mb-0">
                                        <thead>
                                        <tr>
                                            <th scope="col">CV Template</th>
                                            <th><?php echo e(__('Subscription'), false); ?></th>
                                            <th scope="col">Date</th>
                                            <th scope=""> PDF</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="exad-card left text_on_image yes">
                                                        <div class="exad-card-thumb">
                                                            <?php echo $__env->make('components.cv.cv_template_'.$cv->template->file_name.'_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('customer.subscriptions.show',['subscription'=>$cv->subscription_id]), false); ?>">
                                                        <?php echo e($cv->subscription->package->{"name_".$lang}, false); ?></a></td>
                                                <td><?php echo e(date('d/m/Y', strtotime($cv->created_at)), false); ?></td>
                                                <td>
                                                    <button type="button"
                                                            class="btn btn-primary waves-effect waves-light"
                                                            onclick="window.location.href='<?php echo e(route('customer.downloadCV',$cv), false); ?>';">
                                                        Download <i class="fas fa-arrow-down"></i></button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <?php echo $__env->make('customer-cp.partials.cards', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div> <!-- container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/pages/home.blade.php ENDPATH**/ ?>