<script src="<?php echo e(asset('assets/js/dargAndDropUploadFile.js'), false); ?>"></script>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/components/cv/upload_image_js.blade.php ENDPATH**/ ?>