<br>
<ul class="uleducation add-list"
    style="list-style: none">
    <?php $__currentLoopData = $related_summaries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $re_sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li style="margin-bottom: 10px;list-style: none !important;">
            <div class="summaries_data" summary_id="<?php echo e($re_sm->id, false); ?>" summary_content="<?php echo e($re_sm->{"content_".$cv_lang}, false); ?>"
                 onclick="addSummaryData('<?php echo e($re_sm->id, false); ?>','<?php echo e($re_sm->{"content_".$cv_lang}, false); ?>')" type="add"><span class="add-remove"><i class="fas fa-plus-circle"></i></span> <?php echo e($re_sm->{"content_".$cv_lang}, false); ?></div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/ajax/get_summaries_suggestions.blade.php ENDPATH**/ ?>