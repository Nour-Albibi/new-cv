<div id="added_language_<?php echo e($new_language_num, false); ?>">
    <div id="wpforms-626-field_5-container" class="wpforms-field wpforms-field-html wpforms-two-thirds wpforms-first"
         data-field-id="5">
        <div id="wpforms-626-field_5">
            <hr>
        </div>
    </div>
    <div id="wpforms-626-field_6-container"
         class="wpforms-field wpforms-field-html wpforms-one-third"
         data-field-id="6">
        <div id="wpforms-626-field_6">
            <button type="button" style="display: inline-block;
        vertical-align: middle;
        background: #024851;
        height: auto;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        padding: 5px;
        border-radius: 5px;" type="button" onclick="RemoveAddedItem('added_language_<?php echo e($new_language_num, false); ?>')">-
            </button>
        </div>
    </div>
<div class="wpforms-field-container">
    <div id="wpforms-626-field_2-container"
         class="wpforms-field wpforms-field-select wpforms-field-select-style-classic"
         data-field-id="2">
        <label class="wpforms-field-label"
               for="wpforms-626-field_2"><?php echo e(__('LANGUAGES'), false); ?></label><select
            id="wpforms-626-field_2" class="wpforms-field-large"
            name="language_<?php echo e($new_language_num, false); ?>[language_id]">
            <option value=""><?php echo e(__('Select Language'), false); ?></option>
            <?php $__currentLoopData = $alanguages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alanguage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($alanguage->id, false); ?>"><?php echo e($alanguage->{"name_".$cv_lang}, false); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div id="wpforms-626-field_3-container"
         class="wpforms-field wpforms-field-select wpforms-field-select-style-classic"
         data-field-id="3">
        <label class="wpforms-field-label"
               for="wpforms-626-field_3"><?php echo e(__('LEVEL'), false); ?></label><select
            id="wpforms-626-field_3" class="wpforms-field-large"
            name="language_<?php echo e($new_language_num, false); ?>[level_<?php echo e($cv_lang, false); ?>]">
            <option value=""><?php echo e(__('Select Level'), false); ?></option>
            <option value="Beginner"><?php echo e(__('Beginner'), false); ?></option>
            <option value="Elementary"><?php echo e(__('Elementary'), false); ?></option>
            <option value="Intermediate"><?php echo e(__('Intermediate'), false); ?></option>
            <option value="UpperIntermediate"><?php echo e(__('Upper intermediate'), false); ?></option>
            <option value="Advanced"><?php echo e(__('Advanced'), false); ?></option>
            <option value="Fluent"><?php echo e(__('Fluent'), false); ?></option>
            <option value="Native"><?php echo e(__('Native'), false); ?></option>
        </select>
    </div>
    <div id="wpforms-626-field_4-container"
         class="wpforms-field wpforms-field-text" data-field-id="4">
        <label class="wpforms-field-label"
               for="wpforms-626-field_4"><?php echo e(__('ADDITIONAL INFORMATION (OPTIONAL)'), false); ?></label>
        <input type="text" id="wpforms-626-field_4" class="wpforms-field-large"
               name="language_<?php echo e($new_language_num, false); ?>[information_<?php echo e($cv_lang, false); ?>]"
               placeholder="<?php echo e(__('ADDITIONAL INFORMATION (OPTIONAL)'), false); ?>">
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/ajax/add_language.blade.php ENDPATH**/ ?>