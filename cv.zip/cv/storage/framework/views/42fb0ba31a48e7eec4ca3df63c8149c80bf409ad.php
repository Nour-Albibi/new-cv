<div class="vertical-menu">

    <div data-simplebar class="h-100">


        <div class="user-sidebar text-center">
            <div class="dropdown">
                <div class="user-img">
                    <img src="<?php echo e(asset('customer-assets/images/users/avatar-7.jpg'), false); ?>" alt="" class="rounded-circle">
                    <span class="avatar-online bg-success"></span>
                </div>
                <div class="user-info">
                    <h5 class="mt-3 font-size-16 text-white">

                        <?php if(auth()->guard('customer')->check()): ?>
                            <li class="elementor-icon-list-item elementor-inline-item">
                                <a href="#">
                                    <span
                                        class="elementor-icon-list-text">
                                        <?php echo e(Auth::guard('customer')->user()->first_name.' '.Auth::guard('customer')->user()->last_name, false); ?>

                                    </span>
                                </a>
                            </li>
                        <?php endif; ?>

                    </h5>
                    <span class="font-size-13 text-white-50">Customer</span>
                </div>
            </div>
        </div>



        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title"><?php echo e(__('Menu'), false); ?></li>

                <li>
                    <a href="<?php echo e(route('customer.dashboard'), false); ?>" class="waves-effect">
                        <i class="dripicons-home"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('customer.CVs'), false); ?>" class=" waves-effect">
                        <i class="dripicons-calendar"></i>
                        <span style="font-size: small;">CV Managment</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('customer.subscriptions'), false); ?>" class=" waves-effect">
                        <i class="dripicons-calendar"></i>
                        <span style="font-size: small;">Supcription Managment</span>
                    </a>
                </li>

                <li>
                    <a href="#" class=" waves-effect">
                        <i class="dripicons-message"></i>
                        <span style="font-size: small;">Chat</span>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('customer.viewedmyCV'), false); ?>" class=" waves-effect">
                        <i class="dripicons-calendar"></i>
                        <span style="font-size: small;">Viewed my CV</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/partials/sidebar.blade.php ENDPATH**/ ?>