<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <title> Customer Dashboard </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="Themesdesign" name="author" />
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('customer-assets/images/favicon1.ico'), false); ?>">

        <!-- Bootstrap Css -->
        <link href="<?php echo e(asset('customer-assets/css/bootstrap.min.css'), false); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
        <!-- Icons Css -->
        <link href="<?php echo e(asset('customer-assets/css/icons.min.css'), false); ?>" rel="stylesheet" type="text/css" />
        <!-- App Css-->
        <link href="<?php echo e(asset('customer-assets/css/app.min.css'), false); ?>" id="app-style" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;500;600;800&display=swap" rel="stylesheet">

        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" id="app-style" rel="stylesheet" type="text/css" />
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/fontawesome.min.css" id="app-style" rel="stylesheet" type="text/css" />

        <style>
            @import url('https://fonts.googleapis.com/css2?family=Domine:wght@400;500;600;700&display=swap');
          </style>
         <style>
            @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;500;600;800&display=swap');
          </style>
        <style>
            *{
                font-family: 'Domine', serif;
            }
    </style>
       <style>
        .bg-primary2 {
        --bs-bg-opacity: 1;
        background-color: #024a53;
    }
    .btn-primary2{
        background-color: #024a53;
        color: #fff;
    }
    .btn-primary2:hover{
        background-color: #024a53;
        color: #fff;
    }
    .bg-soft-success {
    background-color: #3f757c!important;
}
    .ele-button {

       color: #FFFFFF;
       background-color: transparent;
       background-image: linear-gradient(170deg, #024a53 0%, #024a53 100%);
       border-radius: 5px 5px 5px 5px;
       padding: 16px 35px 16px 35px;}

       .ele-button:hover {

      color: #FFFFFF;
      background-color: transparent;
      background-image: linear-gradient(170deg, #1d545c 0%, #1d555c 100%);
      border-radius: 5px 5px 5px 5px;
      padding: 16px 35px 16px 35px;}
    .text-primary2{
     color: #515151;
    }
        .seperator {
      float: left;
      width: 100%;
      border-top: 1px solid #ccc;
      text-align: center;
      margin: 50px 0 0;
    }
    .seperator b {
      width: 40px;
      height: 40px;
      font-size: 16px;
      text-align: center;
      line-height: 40px;
      background: #fff;
      display: inline-block;
      border: 1px solid #e0e0e0;
      border-radius: 50%;
      position: relative;
      top: -22px;
      z-index: 1;
    }
    .social-icon button {
        font-size: 20px;
        color: white;
        height: 50px;
        width: 50px;
        background: #515151;
        border-radius: 60%;
        margin: 0px 10px;
        border: none;
        cursor: pointer;
        text-align: center;
    }
    .social-icon{
        text-align: center;
    }
    .form-check-input:checked {
        background-color: #515151;
        border-color: #515151;
    }
       </style>

    </head>


    <body>

        <!-- Begin page -->
        <div id="layout-wrapper">

            <?php echo $__env->make('customer-cp.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ========== Left Sidebar Start ========== -->
            <?php echo $__env->make('customer-cp.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">

                    <!-- start page title -->
                    <div class="page-title-box">
                        <div class="container-fluid">
                         <div class="row align-items-center">
                             <div class="col-sm-6">
                                 <div class="page-title">
                                     <h4><?php echo $__env->yieldContent('title', 'CV2'); ?> </h4>
                                         <ol class="breadcrumb m-0">

                                             <li class="breadcrumb-item active"></li>
                                         </ol>
                                 </div>
                             </div>
                             <div class="col-sm-6">
                                <div class="float-end d-none d-sm-block">

                                </div>
                             </div>
                         </div>
                        </div>
                     </div>
                     <!-- end page title -->


                    <div class="container-fluid">

                        <div class="page-content-wrapper">

                            <?php echo $__env->yieldContent('content'); ?>

                        </div>


                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->



                <?php echo $__env->make('customer-cp.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->



        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('customer-assets/libs/jquery/jquery.min.js'), false); ?>"></script>
        <script src="<?php echo e(asset('customer-assets/libs/bootstrap/js/bootstrap.bundle.min.js'), false); ?>"></script>
        <script src="<?php echo e(asset('customer-assets/libs/metismenu/metisMenu.min.js'), false); ?>"></script>
        <script src="<?php echo e(asset('customer-assets/libs/simplebar/simplebar.min.js'), false); ?>"></script>
        <script src="<?php echo e(asset('customer-assets/libs/node-waves/waves.min.js'), false); ?>"></script>

        <script src="<?php echo e(asset('customer-assets/js/app.js'), false); ?>"></script>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/layouts/app.blade.php ENDPATH**/ ?>