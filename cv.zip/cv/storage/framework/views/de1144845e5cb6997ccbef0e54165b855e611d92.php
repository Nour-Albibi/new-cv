<script>
    tinymce.init({
        selector: 'textarea#<?php echo e($selector, false); ?>',
        plugins: 'codesample lists  wordcount',
        menubar: '',
        toolbar: 'fontfamily | fontsize | forecolor backcolor  ltr rtl|  bold italic underline  | align lineheight | numlist bullist indent outdent',
    });
</script>
<style>
    .tox .tox-edit-area__iframe {
        background-color: #fff !important;
    }

    .tox-statusbar {
        display: none !important;
    }

    .tox-toolbar__primary {
        justify-content: space-around;
    }
</style>
<textarea id="<?php echo e($selector, false); ?>" class="wpforms-field-medium skill_content"
          name="content_<?php echo e($lang, false); ?>">
  <?php echo $slot ?? ''; ?>

</textarea>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/components/cv/tiny_editor.blade.php ENDPATH**/ ?>