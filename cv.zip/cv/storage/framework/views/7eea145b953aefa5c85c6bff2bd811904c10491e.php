<!DOCTYPE html>
<html lang="en" class="direction-ltr">
<head>
    <title><?php echo e(__('CV'), false); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('cv-templates/cv3/css/cv3_pdf.css'), false); ?>" />
    <!--Custom CSS-->
    <style>
        .header .main-title{
            color: <?php echo e($cv->template_color ?? "#2A5978", false); ?>  !important;
        }
        .contact_info{
            border-top:1px solid <?php echo e($cv->template_color ?? "#2A5978", false); ?>  !important;
        }
        h5.section-title{
            color: <?php echo e($cv->template_color ?? "#2A5978", false); ?>  !important;
        }
    </style>
</head>
<body>
<?php ($cv_lang=$cv->cv_language); ?>
<div class="Home">
    <div class="main_row">
        <div class="header">
            <div class="text-center main-title"><h3>
                    <?php if($cv_lang=="en"): ?>
                        <?php echo e($cv->first_name.' '.$cv->surename, false); ?>

                    <?php else: ?>
                        <?php echo e($cv->first_name_ar.' '.$cv->surename_ar, false); ?>

                    <?php endif; ?>
                </h3>
            </div>
            <?php if(!empty($cv->{"address_".$cv_lang })): ?>
                <p class="text-center">
                    <?php echo e($cv->{"address_".$cv_lang }, false); ?>

                </p>
            <?php endif; ?>
            <p class="text-center">
                <?php echo e($cv->phone, false); ?>, <?php echo e($cv->email, false); ?>

            </p>
        </div>
        <div class="col-main">
            <?php if(!empty($cv->{"summary_content_".$cv_lang})): ?>

                <div class="summery-section section section-row">
                    <div class="head_title">
                        <h5 class="section-title text-left"><?php echo e(__('PROFESSIONAL SUMMARY'), false); ?></h5>
                    </div>
                    <div class="section-description mt-15" style="display:table">
                        <div class="col" style="display:table-cell;width:160px;"></div>
                        <div class="col">
                            <p><?php echo $cv->{"summary_content_".$cv_lang}; ?></p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_work_history)): ?>
                <div class="space-30 bordered"></div>
                <div class="experience-section section section-row">
                    <div class="head_title">
                        <h5 class="section-title text-left"><?php echo e(__('EXPERIENCE'), false); ?></h5>
                    </div>
                    <?php $__currentLoopData = $cv->customer_cv_work_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="section-description mt-15 experience-item">
                            <div class="col">
                                <?php echo e(date("m-Y",strtotime($work->start_date)), false); ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($work->end_date)), false); ?>

                            </div>
                            <div class="col">
                                <p class="strong" style="max-width:285px"><?php echo e($work->{"job_title_".$cv_lang}, false); ?></p>
                                <p class="strong"><?php echo e($work->{"employeer_".$cv_lang}, false); ?></p>
                                <?php echo $work->{"experience_description_".$lang }; ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_project)): ?>
                <div class="space-30 bordered"></div>
                <div class="experience-section section section-row">
                    <div class="head_title">
                        <h5 class="section-title text-left"><?php echo e(__('Projects'), false); ?></h5>
                    </div>
                    <?php $__currentLoopData = $cv->customer_cv_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="section-description mt-15 experience-item">
                            <div class="col">
                                <?php if(!empty($project->start_date)): ?><?php echo e(date("m-Y",strtotime($project->start_date)), false); ?>  <?php endif; ?>
                                <?php if(!empty($project->end_date)): ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($project->end_date)), false); ?> <?php endif; ?>
                            </div>
                            <div class="col">
                                <div
                                    style="display:flex;margin-bottom: 4px;">
                                    <p class="strong" style="max-width:285px"><?php echo e(__("Project Name"), false); ?>

                                        :<?php echo e($project->{"project_name_".$cv_lang}, false); ?></p>
                                </div>
                                <p class="strong"><?php echo e($project->{"description_".$cv_lang}, false); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_education)): ?>
                <div class="space-30"></div>
                <div class="education-section section section-row">
                    <div class="head_title">
                        <h5 class="section-title text-left"><?php echo e(__('EDUCATION'), false); ?></h5>
                    </div>
                    <?php $__currentLoopData = $cv->customer_cv_education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="section-description mt-15 education-item">
                            <div class="col" style="width:160px;">
                                <?php echo e(date("m-Y",strtotime($edu->start_date)), false); ?>

                                - <?php echo e(date("m-Y",strtotime($edu->end_date)), false); ?>

                            </div>
                            <div class="col">
                                <div style="display: flex">
                                    <p class="strong">BA (Hons) : </p>
                                    <p><?php echo e($edu->{"field_study_".$cv_lang}, false); ?>

                                    </p>
                                </div>
                                <div style="display: flex">
                                    <p class="strong"><?php echo e($edu->{"institution_name_".$cv_lang}, false); ?></p>
                                    <p>- <?php echo e($edu->{"city_".$cv_lang}, false); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(!empty($cv->{"skills_content_".$cv_lang})): ?>
                <div class="space-30 bordered"></div>
                <div class="education-section section section-row">
                    <div class="head_title">
                        <h5 class="section-title text-left"><?php echo e(__('SKILLS'), false); ?></h5>
                    </div>
                    <div class="skills_area">
                        <div class="col" style="width:160px;"></div>
                        <div class="col">
                            <?php echo $cv->{"skills_content_".$cv_lang}; ?>

                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_course)): ?>
                <div class="space-30 bordered"></div>
                <div class="experience-section section section-row">
                    <div class="head_title">
                        <h5 class="section-title text-left"><?php echo e(__('Courses'), false); ?></h5>
                    </div>
                    <?php $__currentLoopData = $cv->customer_cv_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="section-description mt-15 experience-item">
                            <div class="col">
                                <?php echo e(date("m-Y",strtotime($course->start_date)), false); ?>

                                - <?php echo e(date("m-Y",strtotime($course->end_date)), false); ?>

                            </div>
                            <div class="col">
                                <div style="display: flex">
                                    <p class="strong"><?php echo e(__('Course Name: '), false); ?> </p>
                                    <p><?php echo e($course->{"course_name_".$cv_lang}, false); ?></p>
                                </div>
                                <div style="display: flex">
                                    <p class="strong"><?php echo e(__('Trainer: '), false); ?><?php echo e($course->{"trainer_".$cv_lang}, false); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv-templates/cv3_pdf.blade.php ENDPATH**/ ?>