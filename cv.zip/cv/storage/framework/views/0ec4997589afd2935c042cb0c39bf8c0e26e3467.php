<!DOCTYPE html>
<html lang="en" class="direction-ltr">
<head>
    <title><?php echo e(__('CV'), false); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="<?php echo e(asset('cv-templates/cv4/css/cv4_pdf.css'), false); ?>" rel="stylesheet"/>
    <!--Custom CSS-->
    <style>
        .header {
            background-color: <?php echo e($cv->template_color ?? "#009acc", false); ?>  !important;
        }

        h5.section-title {
            color: <?php echo e($cv->template_color ?? "#496267", false); ?>  !important;
        }
        .bordered {
            border-bottom: 4px solid <?php echo e($cv->template_color ?? "#496267", false); ?>;
        }
    </style>
</head>
<body>
<div class="Home">
    <div class="row">
        <div class="header">
            <div class="main-title pt-50"><h3>
                    <?php if($lang=="en"): ?>
                        <?php echo e($cv->first_name.' '.$cv->surename, false); ?>

                    <?php else: ?>
                        <?php echo e($cv->first_name_ar.' '.$cv->surename_ar, false); ?>

                    <?php endif; ?>
                </h3></div>
            <div class="row contact_info" style="text-align:center">
                <center>
                    <ul class="contact_info_list " >
                        <?php if(!empty($cv->{"address_".$lang })): ?>
                            <li class="address"><?php echo e($cv->{"address_".$lang }, false); ?></li>
                        <?php endif; ?>
                        <?php if(!empty($cv->phone)): ?>
                            <li class="phone"><?php echo e($cv->phone, false); ?></li>
                        <?php endif; ?>
                        <?php if(!empty($cv->email)): ?>
                            <li class="email"><?php echo e($cv->email, false); ?></li>
                        <?php endif; ?>
                    </ul>
                </center>
            </div>
        </div>
        <div class="col-main">
            <div class="space-30"></div>
            <?php if(!empty($cv->{"summary_content_".$lang})): ?>
                <div class="space-30 bordered"></div>
                <div class="summery-section section section-row">
                    <div class="col">
                        <h5 class="section-title text-left"><?php echo e(__('PROFESSIONAL SUMMARY'), false); ?></h5>
                    </div>
                    <div class="col">
                        <div class="section-description mt-15">
                            <p><?php echo $cv->{"summary_content_".$lang}; ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_work_history)): ?>
                <div class="space-30 bordered"></div>
                <div class="experience-section section section-row">
                    <div class="col">
                        <h5 class="section-title text-left"><?php echo e(__('EXPERIENCE'), false); ?></h5>
                    </div>
                    <div class="col">
                        <?php $__currentLoopData = $cv->customer_cv_work_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="section-description mt-15 experience-item">
                                <p class="strong" style="max-width:285px"><?php echo e($work->{"job_title_".$lang}, false); ?>

                                    <?php echo e(date("m-Y",strtotime($work->start_date)), false); ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($work->end_date)), false); ?>

                                </p>
                                <p class="strong"><?php echo e($work->{"employeer_".$lang}, false); ?></p>
                                <?php echo $work->{"experience_description_".$lang }; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_project)): ?>
                <div class="space-30 bordered"></div>
                <div class="experience-section section section-row">
                    <div class="col">
                        <h5 class="section-title text-left"><?php echo e(__('Projects'), false); ?></h5>
                    </div>
                    <div class="col">
                        <?php $__currentLoopData = $cv->customer_cv_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="section-description mt-15 experience-item">
                                <p class="strong" style="max-width:285px"><?php echo e(__("Project Name"), false); ?>

                                    :<?php echo e($project->{"project_name_".$lang}, false); ?>

                                </p>
                                <p class="strong">
                                    <?php if(!empty($project->start_date)): ?><?php echo e(date("m-Y",strtotime($project->start_date)), false); ?>  <?php endif; ?>
                                    <?php if(!empty($project->end_date)): ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($project->end_date)), false); ?> <?php endif; ?>
                                </p>
                                <p><?php echo e($project->{"description_".$lang}, false); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_education)): ?>
                <div class="space-30 bordered"></div>
                <div class="education-section section section-row">
                    <div class="col">
                        <h5 class="section-title text-left"><?php echo e(__('EDUCATION'), false); ?></h5>
                    </div>
                    <div class="col">
                        <?php $__currentLoopData = $cv->customer_cv_education; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="section-description mt-15 education-item">
                                <p class="strong"><?php echo e(__('Field Of Study'), false); ?> : <?php echo e($edu->{"field_study_".$lang}, false); ?>,
                                    <?php if(!empty($edu->start_date)): ?>
                                        <?php echo e(date("m-Y",strtotime($edu->start_date)), false); ?>

                                        -
                                    <?php endif; ?>
                                    <?php if(!empty($edu->end_date)): ?>
                                        <?php echo e(date("m-Y",strtotime($edu->end_date)), false); ?>

                                    <?php endif; ?>
                                    <?php if(!empty($edu->current)): ?>
                                        <?php echo e(__(' current'), false); ?>

                                    <?php endif; ?></p>
                                <p class="strong"><?php echo e($edu->{"institution_name_".$lang}, false); ?>

                                    - <?php echo e($edu->{"city_".$lang}, false); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(count($cv->customer_cv_course)): ?>
                <div class="space-30 bordered"></div>
                <div class="education-section section section-row">
                    <div class="col">
                        <h5 class="section-title text-left"><?php echo e(__('Courses'), false); ?></h5>
                    </div>
                    <div class="col">
                        <?php $__currentLoopData = $cv->customer_cv_course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="section-description mt-15 education-item">
                                <p class="strong"><?php echo e(__('Course Name: '), false); ?> </p>
                                <p><?php echo e($course->{"course_name_".$lang}, false); ?>,
                                    <?php if(!empty($course->start_date)): ?>
                                        <?php echo e(date("m-Y",strtotime($course->start_date)), false); ?>

                                    <?php endif; ?>
                                    <?php if(!empty($course->end_date)): ?>
                                        - <?php echo e(date("m-Y",strtotime($course->end_date)), false); ?>

                                    <?php endif; ?>
                                </p>
                                <p class="strong"><?php echo e(__('Trainer: '), false); ?><?php echo e($course->{"trainer_".$lang}, false); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(!empty($cv->{"skills_content_".$lang})): ?>
                <div class="space-30 bordered"></div>
                <div class="education-section section section-row">
                    <div class="col">
                        <h5 class="section-title text-left"><?php echo e(__('SKILLS'), false); ?></h5>
                    </div>
                    <div class="col">
                        <div class="section-description mt-15 education-item">
                            <p><?php echo $cv->{"skills_content_".$lang}; ?> </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv-templates/cv4_pdf.blade.php ENDPATH**/ ?>