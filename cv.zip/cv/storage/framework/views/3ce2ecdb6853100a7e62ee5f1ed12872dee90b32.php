<div id="added_project_<?php echo e($new_project_num, false); ?>">
    <div id="wpforms-626-field_5-container" class="wpforms-field wpforms-field-html wpforms-two-thirds wpforms-first"
         data-field-id="5">
        <div id="wpforms-626-field_5">
            <hr>
        </div>
    </div>
    <div id="wpforms-626-field_6-container"
         class="wpforms-field wpforms-field-html wpforms-one-third"
         data-field-id="6">
        <div id="wpforms-626-field_6">
            <button type="button" style="display: inline-block;
        vertical-align: middle;
        background: #024851;
        height: auto;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        padding: 5px;
        border-radius: 5px;" type="button" onclick="RemoveAddedItem('added_project_<?php echo e($new_project_num, false); ?>')">-
            </button>
        </div>
    </div>
<div class="wpforms-field-container">
    <div id="wpforms-519-field_1-container"
         class="wpforms-field wpforms-field-text" data-field-id="1">
        <label class="wpforms-field-label"
               for="wpforms-519-field_1"><?php echo e(__('PROJECT NAME'), false); ?></label><input
            type="text" id="wpforms-519-field_1"
            class="wpforms-field-large" name="project_<?php echo e($new_project_num, false); ?>[project_name_<?php echo e($cv_lang, false); ?>]"
            placeholder="<?php echo e(__('PROJECT NAME'), false); ?>">
    </div>
    <div id="wpforms-519-field_3-container"
         class="wpforms-field wpforms-field-text" data-field-id="3">
        <label class="wpforms-field-label"
               for="wpforms-519-field_3"><?php echo e(__('DESCRIPTION OF WORK ON THE PROJECT'), false); ?></label>
        <textarea name="project_<?php echo e($new_project_num, false); ?>[description_<?php echo e($cv_lang, false); ?>]"  class="wpforms-field-large"
         placeholder="<?php echo e(__('DESCRIPTION OF WORK ON THE PROJECT'), false); ?>"></textarea>
    </div>
    <div class="dates_container">
        <div id="wpforms-519-field_4-container"
             class="wpforms-field wpforms-field-date-time wpforms-one-half wpforms-first"
             data-field-id="4">
            <label class="wpforms-field-label"
                   for="wpforms-519-field_4"><?php echo e(__('START DATE'), false); ?></label>
            <div class="wpforms-datepicker-wrap">
                <input type="date" id="wpforms-519-field_4"
                       class="start_date wpforms-field-date-time-date wpforms-datepicker wpforms-field-large"
                       data-date-format="m/d/Y"
                       data-disable-past-dates="0" data-input="true"
                       input_name="project_start_date"
                       project_num="<?php echo e($new_project_num, false); ?>"
                       name="project_<?php echo e($new_project_num, false); ?>[start_date]">
            </div>
        </div>
        <div id="wpforms-519-field_5-container"
         class="wpforms-field wpforms-field-date-time wpforms-one-half"
         data-field-id="5">
        <label class="wpforms-field-label"
               for="wpforms-519-field_5"><?php echo e(__('END DATE'), false); ?></label>
        <div class="wpforms-datepicker-wrap">
            <input type="date" id="wpforms-519-field_5"
                   class="end_date wpforms-field-date-time-date wpforms-datepicker wpforms-field-large"
                   data-date-format="m/d/Y"
                   data-disable-past-dates="0" data-input="true"
                   input_name="project_end_date"
                   project_num="<?php echo e($new_project_num, false); ?>"
                   name="project_<?php echo e($new_project_num, false); ?>[end_date]">
        </div>
    </div>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/ajax/add_project.blade.php ENDPATH**/ ?>