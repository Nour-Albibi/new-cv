<?php $__env->startSection('title'); ?>
    cvs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="page-content-wrapper">

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex" style="justify-content: space-between;margin-bottom: 8px">
                            <h5>My CVs</h5>
                                <a href="<?php echo e(route('cv.create'), false); ?>" class=" btn btn-success"><?php echo e(__('Create CV'), false); ?></a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-centered table-nowrap mb-0">
                                    <thead>
                                    <tr>
                                        <th scope="col"> CV Template</th>
                                        <th><?php echo e(__('Subscription'), false); ?></th>
                                        <th scope="col"> Date</th>
                                        <th scope=""> PDF</th>
                                        <th><?php echo e(__('Action'), false); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="exad-card left text_on_image yes"
                                                     style="overflow:hidden;max-width:265px;max-height:350px;">
                                                    <div class="exad-card-thumb">
                                                        <?php echo $__env->make('components.cv.cv_template_'.$cv->template->file_name.'_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('customer.subscriptions.show',['subscription'=>$cv->subscription_id]), false); ?>">
                                                    <?php echo e($cv->subscription->package->{"name_".$lang}, false); ?></a></td>
                                            <td><?php echo e(date('d/m/Y', strtotime($cv->created_at)), false); ?></td>
                                            <td>
                                                <button type="button" class="btn btn-primary waves-effect waves-light"
                                                        onclick="window.location.href='<?php echo e(route('customer.downloadCV',$cv), false); ?>';">
                                                    Download <i class="fas fa-arrow-down"></i></button>
                                            </td>
                                            <?php if($cv->downloads==0): ?>
                                                <td>
                                                    <a href="<?php echo e(route('customer.editCV',['cv'=>$cv->id]), false); ?>"><i
                                                            class="fas fa-pen text-info"></i></a>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php echo $cvs->links(); ?>

                </div>
                <div class="col-xl-4">


                </div>
            </div>

        </div>


    </div> <!-- container-fluid -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/cvs/index.blade.php ENDPATH**/ ?>