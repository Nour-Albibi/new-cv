<?php $__env->startSection('title'); ?>
    <?php echo e(__(' Subscribe to New Package'), false); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <link href="<?php echo e(asset('assets/css/packages.css'), false); ?>" rel="stylesheet"/>
    <style>
        .pricingTable .pricing-content ul li {
            font-size: 15px;
            font-weight: 500;
            text-transform: capitalize;
            line-height: 35px;
            padding: 0 0 0 30px;
            margin: 0 0 5px;
            position: relative;
        }

        .pricingTable .price-value .amount {
            font-size: 37px;
            font-weight: 500;
            line-height: 45px;
            display: inline-block;
        }

        .pricingTable .title {
            color: #fff;
            font-size: 24px;
            font-weight: 300;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin: 0;
        }

        .pacakge_box {
            cursor: pointer;
        }

        .pacakge_box.active .pricingTable {
            border: 4px solid #00b2c7;
        }
    </style>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body  pt-0">
                    <ul class="nav nav-tabs nav-tabs-custom mb-4">
                        <li class="nav-item">
                            <a class="nav-link fw-bold p-3 active"
                               href="#"><?php echo e(__('Subscription INFORMATION Management'), false); ?></a>
                        </li>

                    </ul>
                    <form name="doCheckOut" id="doCheckOut" action="<?php echo e(route('customer.subscriptions.store_new'), false); ?>"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="package_id" value="<?php echo e(request()->package_id, false); ?>"/>
                        <input type="hidden" name="customer_type" value="1"/>
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-lg-11 mx-auto">
                                    <div class="row">
                                        <div class="col-xl-12 col-lg-12 col-md-8 mt-md-0  mt-4">
                                            <div class="form">
                                                <div class="row p-2">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <?php if(!empty(request()->package_id)): ?>
                                                                <label
                                                                    for="fullName"><?php echo e(__('Chosen Package: '), false); ?>

                                                                <?php
                                                                    $package=\App\Models\Package::find(request()->package_id);
                                                                    ?>
                                                               <?php echo e($package->{"name_".$lang }, false); ?> </label>
                                                                <?php else: ?>
                                                                <div class="row mt-4 mb-4 ">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label class="text-uppercase"><?php echo e(__('Choose Your Package'), false); ?></label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            <div class="row" style="margin-bottom:16px;">
                                                                <?php $__currentLoopData = $customerPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="col-md-4 col-sm-6 pacakge_box"
                                                                         package_id="<?php echo e($pkg->id, false); ?>">
                                                                        <div class="pricingTable" style="height: 475px;">
                                                                            <div class="pricingTable-header">
                                                                                <h3 class="title"><?php echo e($pkg->{"name_".$lang}, false); ?></h3>
                                                                            </div>
                                                                            <div class="pricing-content">
                                                                                <div class="price-value">
                                                                                    <span
                                                                                        class="currency"><?php echo e(__('SAR'), false); ?></span>
                                                                                    <span
                                                                                        class="amount"><?php echo e($pkg->total_price, false); ?></span>
                                                                                    <span
                                                                                        class="amount-sm"><?php echo e($pkg->cv_price, false); ?></span>
                                                                                </div>
                                                                                <ul>
                                                                                    <li>Unlimited printing and
                                                                                        downloading
                                                                                        for <?php echo e($pkg->duration*30, false); ?>

                                                                                        days
                                                                                    </li>
                                                                                    <li>Create <?php echo e($pkg->quantity, false); ?> CVs
                                                                                        and cover
                                                                                        letters
                                                                                    </li>
                                                                                    <li>auto-renews at every 4 weeks
                                                                                    </li>
                                                                                    <li class="disable">Cancel at any
                                                                                        time
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                                <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <hr>
                                                    <div class="row mt-4 mb-4 ">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label class="text-uppercase">Payment details</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="profession">Name on card:</label>
                                                            <input type="text" name="name_on_card"
                                                                   class="form-control mb-3"
                                                                   required="required" placeholder="Name on card">
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="address">Card Number:</label>
                                                            <i class="fa fa-credit-card"></i>
                                                            <input type="text" name="card_number" class="form-control"
                                                                   required="required">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="address">Expiry:</label>
                                                            <input type="text" name="expiry" class="form-control"
                                                                   required="required">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="location">CVV:</label>
                                                            <input type="text" name="cvv" class="form-control"
                                                                   required="required">
                                                        </div>
                                                    </div>

                                                    <div class="mt-4 mb-4">
                                                        <h6 class="text-uppercase">Billing Address</h6>
                                                        <div class="row mt-3">
                                                            <div class="col-md-6">
                                                                <div class="inputbox mt-3 mr-2"><input
                                                                        type="text"
                                                                        name="address"
                                                                        class="form-control"
                                                                        required="required">
                                                                    <span>Street Address</span></div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="inputbox mt-3 mr-2"><input
                                                                        type="text"
                                                                        name="city"
                                                                        class="form-control"
                                                                        required="required">
                                                                    <span>City</span></div>
                                                            </div>
                                                        </div>
                                                        <div class="row mt-2">
                                                            <div class="col-md-6">
                                                                <div class="inputbox mt-3 mr-2"><input
                                                                        type="text"
                                                                        name="state"
                                                                        class="form-control"
                                                                        required="required">
                                                                    <span>State/Province</span></div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="inputbox mt-3 mr-2"><input
                                                                        type="text"
                                                                        name="zip_code"
                                                                        class="form-control"
                                                                        required="required">
                                                                    <span>Zip code</span></div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-12 mt-1">
                                                        <div class="form-group text-end">
                                                            <button type="submit" class="btn btn-success"><?php echo e(__('Submit'), false); ?></button>
                                                            <button type="reset" class="btn btn-secondary"><?php echo e(__('Clear'), false); ?></button>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
    <script>
        $('.pacakge_box').on('click', function () {
            $('.pacakge_box').removeClass('active');
            $(this).addClass('active');
            pacakge_id = $(this).attr('package_id');
            $('input[name=package_id]').val(pacakge_id);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/subscriptions/create.blade.php ENDPATH**/ ?>