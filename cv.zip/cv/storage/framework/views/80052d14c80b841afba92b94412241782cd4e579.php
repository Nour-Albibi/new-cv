<script>
    tinymce.init({
        selector: '#<?php echo e($selector, false); ?>',
        plugins: 'codesample lists  wordcount advlist fullscreen',
        menubar: '',
        toolbar: 'undo redo | fontfamily | fontsize | forecolor backcolor  ltr rtl|  bold italic underline  | align lineheight | numlist bullist indent outdent',
        // inline:true
    });
</script>
<style>
    .tox .tox-edit-area__iframe {
        background-color: #fff !important;
    }

    .tox-statusbar {
        display: none !important;
    }

    .tox-toolbar__primary {
        justify-content: space-around;
    }
</style>
<textarea id="<?php echo e($selector, false); ?>" class="wpforms-field-large work_ed works_textarea"
          name="work_<?php echo e($i, false); ?>[experience_description_<?php echo e($lang, false); ?>]">
  <?php echo $slot ?? ''; ?>

</textarea>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/components/cv/tiny_works_editor.blade.php ENDPATH**/ ?>