<section data-particle_enable="false" data-particle-mobile-disabled="false"
         class="skills_tab_container elementor-454 width100 section-tab elementor-section elementor-inner-section elementor-element elementor-element-15352d99 exad-glass-effect-yes elementor-section-full_width elementor-section-height-default elementor-section-height-default exad-sticky-section-no"
         data-id="15352d99" data-element_type="section">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cv.tips_and_preview_area','data' => ['ctemplate' => $chosen_template,'addedItem' => $addedItem,'lang' => $cv_lang]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cv.tips_and_preview_area'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ctemplate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($chosen_template),'addedItem' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($addedItem),'lang' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($cv_lang)]); ?>
        
        <div class="tips_area elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5f785b4 exad-glass-effect-no exad-sticky-section-no"
             data-id="5f785b4" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div
                    class="elementor-element elementor-element-98451db exad-sticky-section-no exad-glass-effect-no hello-element elementor-invisible elementor-widget elementor-widget-heading"
                    data-id="98451db" data-element_type="widget"
                    data-widget_type="heading.default" current_tab="5">
                    <div class="elementor-widget-container">
                        <h4 class="elementor-heading-title elementor-size-default"><?php echo e(__("Next, let’s take care of your"), false); ?>

                        </h4></div>
                </div>
                <div
                    class="elementor-element elementor-element-e0edac4 exad-sticky-section-no exad-glass-effect-no hello-element elementor-invisible elementor-widget elementor-widget-heading"
                    data-id="e0edac4" data-element_type="widget"
                    data-widget_type="heading.default" current_tab="5">
                    <div class="elementor-widget-container">
                        <h3 class="elementor-heading-title elementor-size-default"><?php echo e(__('Skills'), false); ?></h3>
                    </div>
                </div>
                <div
                    class="elementor-element elementor-element-8fc8c3e exad-sticky-section-no exad-glass-effect-no hello-element elementor-invisible elementor-widget elementor-widget-heading"
                    data-id="8fc8c3e" data-element_type="widget"
                    data-widget_type="heading.default" current_tab="5">
                    <div class="elementor-widget-container">
                        <h6 class="elementor-heading-title elementor-size-default"><?php echo e(__("Add four to eight skills from your previous jobs relevant to the job you want. We’ll suggest ones with keywords employers look for based on your title. Don’t have previous experience in the job you’re applying for? Try adding some of the skills suggested for that job title to show you can do it."), false); ?></h6></div>
                </div>
                <div
                    class="elementor-element elementor-element-e0e8c31 elementor-icon-list--layout-traditional elementor-list-item-link-full_width exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-icon-list"
                    data-id="e0e8c31" data-element_type="widget"
                    data-widget_type="icon-list.default">
                    <div class="elementor-widget-container">
                        <ul class="elementor-icon-list-items">
                            <li class="elementor-icon-list-item">
                                <a href="javascript:void(0)" onclick="$('.tips_area').css('visibility','hidden')">
                                        <span class="elementor-icon-list-icon">
                                            <i aria-hidden="true" class="fas fa-chevron-right"></i>
                                        </span>
                                    <span class="elementor-icon-list-text"><?php echo e(__("Don't show me tips anymore"), false); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <div class="skills_tab elementor-container elementor-column-gap-custom">
        <div class="elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-49124a5a exad-glass-effect-no exad-sticky-section-no"
             data-id="49124a5a" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div class="elementor-element elementor-element-20126956 exad-sticky-section-no exad-glass-effect-no hello-element elementor-invisible elementor-widget elementor-widget-heading"
                     data-id="20126956" data-element_type="widget"
                     data-widget_type="heading.default" current_tab="5">
                    <div class="elementor-widget-container">
                        <h4 class="elementor-heading-title elementor-size-default"><?php echo e(__('Highlight relevant skills for the job you want'), false); ?></h4></div>
                </div>
                <div class="elementor-element elementor-element-4a953a8c exad-sticky-section-no exad-glass-effect-no hello-element elementor-invisible elementor-widget elementor-widget-heading"
                     data-id="4a953a8c" data-element_type="widget"
                     data-widget_type="heading.default" current_tab="5">
                    <div class="elementor-widget-container">
                        <h6 class="elementor-heading-title elementor-size-default"><?php echo e(__('Start with our
                            expert recommendations by job title or pull the skills required from the
                            job description'), false); ?></h6></div>
                </div>
                <div class="elementor-element elementor-element-40c1aed5 elementor-hidden-tablet elementor-hidden-mobile exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-wpforms"
                     data-id="40c1aed5" data-element_type="widget"
                     data-widget_type="wpforms.default">
                    <div class="elementor-widget-container">
                        <div class="wpforms-container wpforms-container-full" id="wpforms-591">
                            <form id="skills_form" class="wpforms-validate wpforms-form"
                                  data-formid="591" method="post" enctype="multipart/form-data"
                                  action="/"
                                  data-token="bd03f5379139322e31b053c6ab97fff9">
                                <?php echo csrf_field(); ?>
                                <input name="skills_content" type="hidden" value="<?php if(!empty($addedItem)): ?><?php echo e($addedItem->model->{"skills_content_".$cv_lang}, false); ?><?php endif; ?>">
                                <noscript class="wpforms-error-noscript"><?php echo e(__('Please enable JavaScript in your browser to complete this form.'), false); ?></noscript>
                                <div class="wpforms-field-container">
                                    <div id="wpforms-591-field_2-container"
                                         class="wpforms-field wpforms-field-text wpforms-one-half wpforms-first"
                                         data-field-id="2">
                                        <label class="wpforms-field-label"
                                               for="wpforms-591-field_2"><?php echo e(__('Search for pre-written examples'), false); ?></label>
                                        <input type="text" id="wpforms-591-field_2" class="wpforms-field-large"
                                                                   name="search_skills_job_title"
                                                                   placeholder="<?php echo e(__('Search Skills for Specific Job Title'), false); ?>">
                                    </div>
                                    <div id="wpforms-591-field_3-container"
                                         class="wpforms-field wpforms-field-html wpforms-one-half"
                                         data-field-id="3">
                                        <div id="wpforms-591-field_3">
                                            <button type="button" class="skills_search_button" onclick="getAllSkillRelatedToJobTitle()"><?php echo e(__('Search'), false); ?></button>
                                        </div>
                                    </div>
                                    <div id="wpforms-591-field_1-container"
                                         class="wpforms-field wpforms-field-textarea wpforms-one-half wpforms-first"
                                         data-field-id="1">
                                        <label class="wpforms-field-label"
                                               for="wpforms-591-field_1"><?php echo e(__('skills for the job you want'), false); ?></label>
                                        <?php $out=''; ?>
                                        <?php $editor_id="wpforms-591-field_1" ?>
                                        <?php if(!empty($addedItem) && count($addedItem->model->customer_cv_skill)): ?>
                                            <?php $__currentLoopData = $addedItem->model->customer_cv_skill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addedSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input type="hidden" class="skills_idss" name="skills_ids[]" value="<?php echo e($addedSkill->id, false); ?>"/>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cv.tiny_editor','data' => ['id' => 'wpforms-591-field_1','selector' => $editor_id,'class' => 'wpforms-field-medium skill_content','name' => 'content_'.e($cv_lang, false).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cv.tiny_editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'wpforms-591-field_1','selector' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($editor_id),'class' => 'wpforms-field-medium skill_content','name' => 'content_'.e($cv_lang, false).'']); ?><?php echo $addedItem->model->{"skill_content_".$cv_lang}; ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                       <?php else: ?>
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cv.tiny_editor','data' => ['id' => 'wpforms-591-field_1','class' => 'wpforms-field-medium skill_content','name' => 'content_'.e($cv_lang, false).'','selector' => $editor_id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cv.tiny_editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'wpforms-591-field_1','class' => 'wpforms-field-medium skill_content','name' => 'content_'.e($cv_lang, false).'','selector' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($editor_id)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        <input type="hidden" class="skills_idss" name="skills_ids[]" value=""/>
                                        <?php endif; ?>
                                    </div>
                                    <div id="wpforms-591-field_4-container"
                                         class="wpforms-field wpforms-field-html wpforms-one-half"
                                         data-field-id="4">
                                        <div id="skills_suggestions">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/steps_sections/skills.blade.php ENDPATH**/ ?>