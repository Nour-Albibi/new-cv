<?php $__env->startSection('title'); ?>
    Viewed My CVs
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_css'); ?>
    <link href="<?php echo e(asset('customer-assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css'), false); ?>" rel="stylesheet" type="text/css" defer />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('customer-assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css'), false); ?>" rel="stylesheet" type="text/css" defer />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
     <div class="container-fluid">

        <div class="page-content-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body  pt-0">
                            <ul class="nav nav-tabs nav-tabs-custom mb-4">
                                <li class="nav-item">
                                    <a class="nav-link fw-bold p-3 active" href="#">Viewed MY CV </a>
                                </li>

                            </ul>
                            <div class="table-responsive">
                                <table class="table table-centered datatable dt-responsive nowrap " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>CV Template</th>
                                        <th>Company Name</th>
                                        <th>how often</th>
                                        <th> Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customer_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div class="exad-card left text_on_image yes"
                                                         style="overflow:hidden;max-width:265px;max-height:350px;">
                                                        <div class="exad-card-thumb">
                                                            <?php echo $__env->make('components.cv.cv_template_'.$view->cv->template->file_name.'_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td><?php echo e($view->company->company_name, false); ?></td>
                                                <td>
                                                    <div class="badge badge-soft-success font-size-12"> <?php echo e($view->how_often, false); ?></div>
                                                </td>
                                                <td><?php echo e(date('d/m/Y', strtotime($view->cv->created_at)), false); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end row -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
    <script src="<?php echo e(asset('customer-assets/libs/datatables.net/js/jquery.dataTables.min.js'), false); ?>"></script>
    <script src="<?php echo e(asset('customer-assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js'), false); ?>"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('customer-assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js'), false); ?>"></script>
    <script src="<?php echo e(asset('customer-assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js'), false); ?>"></script>

    <script src="<?php echo e(asset('customer-assets/js/pages/ecommerce-datatables.init.js'), false); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/cvs/views.blade.php ENDPATH**/ ?>