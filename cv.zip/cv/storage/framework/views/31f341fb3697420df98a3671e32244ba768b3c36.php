

<?php $__env->startSection('title'); ?>
    New Subscription
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>




















<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body  pt-0">
                <ul class="nav nav-tabs nav-tabs-custom mb-4">
                    <li class="nav-item" >
                        <a class="nav-link fw-bold p-3 active" href="#">New subscription</a>
                    </li>

                </ul>
                <div class="table-responsive">


                    <table class="table table-centered datatable dt-responsive nowrap " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead class="thead-light">
                            <tr>

                                <th>Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>duaration</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($package->{"name_".$lang} ?? '', false); ?></td>
                                <td><?php echo e($package-> {"description_".$lang} ?? '', false); ?></td>
                                <td><?php echo e($package->quantity, false); ?></td>
                                <td><?php echo e($package->total_price, false); ?>$</td>
                                <td><?php echo e($package->duration, false); ?>&nbspMonth</td>

                                <td>
                                    <a href="<?php echo e(route('customer.subscriptions.buy',$package), false); ?>">Buy</a>
                                </td>


                            </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/subscriptions/new.blade.php ENDPATH**/ ?>