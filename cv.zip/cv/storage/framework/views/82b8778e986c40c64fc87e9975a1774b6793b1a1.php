<link href="<?php echo e(asset('cv-templates/cv4/css/cv4_card.css'), false); ?>" rel="stylesheet" defer/>
<?php if(isset($cv) &&  !empty($cv)): ?>
    <style>
        .card-header{
            background-color: <?php echo e($cv->template_color ?? session('chosen_cv_color'), false); ?>;
        }
        h5.card-section-title{
            color: <?php echo e($cv->template_color ?? session('chosen_cv_color'), false); ?>;
        }
    </style>
<?php else: ?>
<style>

    .card-header{
        background-color: <?php echo e(session('chosen_cv_color'), false); ?>;
    }
    h5.card-section-title{
        color: <?php echo e(session('chosen_cv_color'), false); ?>;
    }
</style>
<?php endif; ?>
<div class="card-Home">
    <div class="card-row" style="flex-direction: column">
        <div class="card-header">
            <div class="card-main-title">
                <h3 id="cv_template_name">
                    <?php if(isset($addedItem) && !empty($addedItem)): ?>
                        <?php if($lang=="en"): ?>
                            <?php echo e($addedItem->model->first_name.' '.$addedItem->model->surename, false); ?>

                        <?php else: ?>
                            <?php echo e($addedItem->model->first_name_ar.' '.$addedItem->model->surename_ar, false); ?>

                        <?php endif; ?>
                    <?php elseif(isset($cv) &&  !empty($cv)): ?>
                        <?php if($lang=="en"): ?>
                            <?php echo e($cv->first_name.' '.$cv->surename, false); ?>

                        <?php else: ?>
                            <?php echo e($cv->first_name_ar.' '.$cv->surename_ar, false); ?>

                        <?php endif; ?>
                    <?php else: ?>
                        <?php echo e(__("Your Name"), false); ?>

                    <?php endif; ?>
                </h3></div>
            <div class="card-row card-contact_info" style="text-align:center;">
                    <?php if(isset($addedItem) && !empty($addedItem)): ?>
                    <ul class="card-contact_info_list " >
                        <?php if(!empty($addedItem->model->{"address_".$lang })): ?>
                            <li class="address"><?php echo e($addedItem->model->{"address_".$lang }, false); ?></li>
                        <?php endif; ?>
                        <?php if(!empty($addedItem->model->phone)): ?>
                            <li class="phone"><?php echo e($addedItem->model->phone, false); ?></li>
                        <?php endif; ?>
                        <?php if(!empty($addedItem->model->email)): ?>
                            <li class="email"><?php echo e($addedItem->model->email, false); ?></li>
                        <?php endif; ?>
                    </ul>
                    <?php else: ?>
                        <ul class="card-contact_info_list ">
                            <li class="address">46 Roman Rd, Leeds, LS2 3ZR</li>
                            <li class="phone">07912 345 678</li>
                            <li class="email">dom.webster@example.co.uk</li>
                        </ul>
                    <?php endif; ?>
            </div>
        </div>
        <div class="card-col-main">
            <?php if(isset($addedItem) && !empty($addedItem) && !empty($addedItem->model->{"summary_content_".$lang})): ?>
                <div class="card-space-30 card-bordered"></div>
                <div class="card-summery-section card-section card-section-row">
                    <div class="card-col">
                        <h5 class="card-section-title text-left"><?php echo e(__('PROFESSIONAL SUMMARY'), false); ?></h5>
                    </div>
                    <div class="card-col">
                        <div class="card-section-description card-mt-15">
                            <p><?php echo $addedItem->model->{"summary_content_".$lang}; ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="card-space-30 card-bordered"></div>
                <div class="card-summery-section card-section card-section-row">
                    <div class="card-col">
                        <h5 class="card-section-title text-left">PROFESSIONAL SUMMARY</h5>
                    </div>
                    <div class="card-col">
                        <div class="card-section-description card-mt-15">
                            <p>Accomplished Operations executive with a successful track record
                                overseeing regional Marketing, IT, HR/training and property in
                                company and franchise operations for a large chain of restaurants.
                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php if(isset($addedItem) && !empty($addedItem) && count($addedItem->model->customer_cv_work_history)): ?>
                <div class="card-space-30 card-bordered"></div>
                <div class="card-experience-section card-section card-section-row">
                    <div class="card-col">
                        <h5 class="card-section-title text-left"><?php echo e(__('EXPERIENCE'), false); ?></h5>
                    </div>
                    <div class="card-col">
                        <?php $__currentLoopData = $addedItem->model->customer_cv_work_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card-section-description card-mt-15 card-experience-item">
                                <p class="card-strong" style="max-width:285px"><?php echo e($work->{"job_title_".$lang}, false); ?>

                                    <?php echo e(date("m-Y",strtotime($work->start_date)), false); ?> <?php echo e(__('to'), false); ?> <?php echo e(date("m-Y",strtotime($work->end_date)), false); ?>

                                </p>
                                <p class="card-strong"><?php echo e($work->{"employeer_".$lang}, false); ?></p>
                                <?php echo $work->{"experience_description_".$lang }; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="card-space-30 card-bordered"></div>
                <div class="card-experience-section card-section card-section-row">
                    <div class="card-col">
                        <h5 class="card-section-title text-left">EXPERIENCE</h5>
                    </div>
                    <div class="card-col">
                        <div class="card-section-description card-mt-15 card-experience-item">
                            <p class="card-strong" style="max-width:285px">Executive Vice President 09/2015 to 02/2019</p>
                            <p class="card-strong">Pizza Hut UK & Ireland - St Albans, Herts</p>
                            <ul class="card-work-duties card-mt-16 card-main-list">
                                <li>Led operations involved in running the brand including Marketing,
                                    IT, HR/training, development/construction, property and P&L for 200
                                    store locations.
                                </li>
                                <li>Oversaw operations for all regional company and franchise locations.</li>
                                <li>
                                    Assessed profitability of existing company processes to determine
                                    optimum organisational structure for maximum revenue growth.
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="card-space-30 card-bordered"></div>
            <div class="card-education-section section section-row">
                <div class="card-col">
                    <h5 class="card-section-title text-left">EDUCATION</h5>
                </div>
                <div class="card-col">
                    <div class="card-section-description card-mt-15 card-education-item">
                        <p class="card-strong">BA (Hons) : Business Management, 2006</p>
                        <p class="card-strong">University Of Westminster - Greater London</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/components/cv/cv_template_cv4_card.blade.php ENDPATH**/ ?>