<?php $__env->startSection('title'); ?>
    Subscriptions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body  pt-0">
                    <ul class="nav nav-tabs nav-tabs-custom mb-4">
                        <li class="nav-item">
                            <a class="nav-link fw-bold p-3 active" href="#">Subscription</a>
                        </li>

                    </ul>
                    <div class="table-responsive">

                        <table class="table table-centered datatable dt-responsive nowrap "
                               style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead class="thead-light">
                            <tr>
                                <th>Invoice No#</th>
                                <th>PLAN</th>
                                <th>price</th>
                                <th>start Date</th>
                                <th>Expire Date</th>
                                <th>Payment gateway</th>
                                <th>Status</th>
                                <th>Renew</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    #<?php echo e($subscription->invoice->invoice_no, false); ?>

                                </td>
                                <td>
                                    <?php echo e($subscription->package->{"name_".$lang} ?? '', false); ?>

                                </td>
                                <td><?php echo e($subscription->package->total_price, false); ?> <?php echo e(__('SAR'), false); ?></td>
                                <td>
                                    <?php echo e($subscription->start_date, false); ?>

                                </td>
                                <td>  <div class="badge badge-soft-info font-size-12"><?php echo e($subscription->end_date, false); ?></div></td>
                                <td><?php echo e($subscription->invoice->payment_gateway, false); ?></td>
                                <td>
                                    <?php if($subscription->status == 1): ?>
                                        <div class="badge badge-soft-success font-size-12"><?php echo e(__('Active'), false); ?></div>
                                    <?php elseif($subscription->status == 2): ?>
                                        <div class="badge badge-soft-danger font-size-12"><?php echo e(__('Expired'), false); ?></div>
                                    <?php elseif($subscription->status == 3): ?>
                                        <div class="badge badge-soft-danger font-size-12"><?php echo e(__('Canceled'), false); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(\App\Services\CustomerService::canSubscribeToNewPackage()): ?>
                                        <a href="<?php echo e(url('customer/subscriptions/create_new?package_id='.$subscription->package_id), false); ?>"><i class="fa fa-refresh"></i></a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer-cp.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cv\resources\views/customer-cp/subscriptions/show.blade.php ENDPATH**/ ?>