<section data-particle_enable="false" data-particle-mobile-disabled="false"
         class="elementor-section elementor-inner-section elementor-element elementor-element-d3fb953 elementor-section-full_width elementor-section-content-middle elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
         data-id="d3fb953" data-element_type="section">
    <div class="elementor-container elementor-column-gap-custom">
        <div
            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5944a38a exad-glass-effect-no exad-sticky-section-no"
            data-id="5944a38a" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div
                    class="elementor-element elementor-element-431474a5 elementor-align-left elementor-mobile-align-center exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-button"
                    data-id="431474a5" data-element_type="widget"
                    data-widget_type="button.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-button-wrapper">
                            <a class="elementor-button elementor-button-link elementor-size-sm elementor-animation-float"
                               href="javascript:void(0)" onclick="nextPrev(-1)">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Back</span>
		</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div
            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1aa3f9d6 exad-glass-effect-no exad-sticky-section-no"
            data-id="1aa3f9d6" data-element_type="column">
            <div class="elementor-widget-wrap">
            </div>
        </div>
        <div
            class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-11cb1708 exad-glass-effect-no exad-sticky-section-no"
            data-id="11cb1708" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div
                    class="elementor-element elementor-element-24d99c42 elementor-align-right elementor-mobile-align-center exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-button"
                    data-id="24d99c42" data-element_type="widget"
                    data-widget_type="button.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-button-wrapper">
                            <a class="elementor-button elementor-button-link elementor-size-sm elementor-animation-float"
                               href="javascript:void(0)" onclick="nextPrev(1)">
						<span class="elementor-button-content-wrapper">
						<span class="elementor-button-text">Next: Work History</span>
		</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/wizard_footer.blade.php ENDPATH**/ ?>