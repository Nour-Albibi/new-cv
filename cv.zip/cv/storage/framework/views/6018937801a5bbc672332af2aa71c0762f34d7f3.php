<section data-particle_enable="false" data-particle-mobile-disabled="false"
         class="elementor-section elementor-top-section elementor-element elementor-element-331b8a80 elementor-section-boxed elementor-section-height-default elementor-section-height-default exad-glass-effect-no exad-sticky-section-no"
         data-id="331b8a80" data-element_type="section"
         data-settings="{&quot;background_background&quot;:&quot;gradient&quot;}">
    <div class="elementor-background-overlay"></div>
    <div class="elementor-container elementor-column-gap-default">
        <div
            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-78266998 exad-glass-effect-no exad-sticky-section-no"
            data-id="78266998" data-element_type="column">
            <div class="elementor-widget-wrap elementor-element-populated">
                <div
                    class="elementor-element elementor-element-7e84bba2 elementor-headline--style-highlight exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-animated-headline"
                    data-id="7e84bba2" data-element_type="widget"
                    data-settings="{&quot;highlighted_text&quot;:&quot;CV heading&quot;,&quot;headline_style&quot;:&quot;highlight&quot;,&quot;marker&quot;:&quot;circle&quot;,&quot;loop&quot;:&quot;yes&quot;,&quot;highlight_animation_duration&quot;:1200,&quot;highlight_iteration_delay&quot;:8000}"
                    data-widget_type="animated-headline.default">
                    <div class="elementor-widget-container">
                        <link rel="stylesheet"
                              href="https://projects.datatime4it.com/chtml/wp-content/plugins/elementor-pro/assets/css/widget-animated-headline.min.css">
                        <h2 class="elementor-headline">
                                <span class="elementor-headline-dynamic-wrapper elementor-headline-text-wrapper">
                                    <span class="elementor-headline-dynamic-text elementor-headline-text-active">CV heading</span>
                                </span>
                        </h2>
                    </div>
                </div>
                <div
                    class="elementor-element elementor-element-613fbd2b exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-spacer"
                    data-id="613fbd2b" data-element_type="widget" data-widget_type="spacer.default">
                    <div class="elementor-widget-container">
                        <style>/*! elementor - v3.16.0 - 20-09-2023 */
                            .elementor-column .elementor-spacer-inner {
                                height: var(--spacer-size)
                            }

                            .e-con {
                                --container-widget-width: 100%
                            }

                            .e-con-inner > .elementor-widget-spacer, .e-con > .elementor-widget-spacer {
                                width: var(--container-widget-width, var(--spacer-size));
                                --align-self: var(--container-widget-align-self, initial);
                                --flex-shrink: 0
                            }

                            .e-con-inner > .elementor-widget-spacer > .elementor-widget-container, .e-con > .elementor-widget-spacer > .elementor-widget-container {
                                height: 100%;
                                width: 100%
                            }

                            .e-con-inner > .elementor-widget-spacer > .elementor-widget-container > .elementor-spacer, .e-con > .elementor-widget-spacer > .elementor-widget-container > .elementor-spacer {
                                height: 100%
                            }

                            .e-con-inner > .elementor-widget-spacer > .elementor-widget-container > .elementor-spacer > .elementor-spacer-inner, .e-con > .elementor-widget-spacer > .elementor-widget-container > .elementor-spacer > .elementor-spacer-inner {
                                height: var(--container-widget-height, var(--spacer-size))
                            }

                            .e-con-inner > .elementor-widget-spacer.elementor-widget-empty, .e-con > .elementor-widget-spacer.elementor-widget-empty {
                                position: relative;
                                min-height: 22px;
                                min-width: 22px
                            }

                            .e-con-inner > .elementor-widget-spacer.elementor-widget-empty .elementor-widget-empty-icon, .e-con > .elementor-widget-spacer.elementor-widget-empty .elementor-widget-empty-icon {
                                position: absolute;
                                top: 0;
                                bottom: 0;
                                left: 0;
                                right: 0;
                                margin: auto;
                                padding: 0;
                                width: 22px;
                                height: 22px
                            }</style>
                        <div class="elementor-spacer">
                            <div class="elementor-spacer-inner"></div>
                        </div>
                    </div>
                </div>
                <section data-particle_enable="false" data-particle-mobile-disabled="false"
                         class="elementor-section elementor-inner-section elementor-element elementor-element-76b9534c elementor-section-full_width exad-glass-effect-yes elementor-section-height-default elementor-section-height-default exad-sticky-section-no elementor-invisible"
                         data-id="76b9534c" data-element_type="section"
                         data-settings="{&quot;background_background&quot;:&quot;classic&quot;,&quot;animation&quot;:&quot;fadeIn&quot;}">
                    <div class="elementor-container elementor-column-gap-no">
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-55c1998f exad-glass-effect-no exad-sticky-section-no"
                            data-id="55c1998f" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-196bbbab elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="196bbbab" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">1</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-60645894 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="60645894" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h5 class="font-size-15 " style="text-align: center;">CV heading</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-3246beb5 exad-glass-effect-no exad-sticky-section-no"
                            data-id="3246beb5" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-1332f3fd elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="1332f3fd" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">2</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-6144f202 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="6144f202" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h5 class="font-size-15 " style="text-align: center;">Work history</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-7892430b exad-glass-effect-no exad-sticky-section-no"
                            data-id="7892430b" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-6ecc50ba elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="6ecc50ba" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">3</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-1b38ee80 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="1b38ee80" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h5 class="font-size-15 " style="text-align: center;">Projects</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-3c079888 exad-glass-effect-no exad-sticky-section-no"
                            data-id="3c079888" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-36dd34bd elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="36dd34bd" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">4</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-162bb397 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="162bb397" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h5 class="font-size-15 " style="text-align: center;">Education</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-62b5156f exad-glass-effect-no exad-sticky-section-no"
                            data-id="62b5156f" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-10505580 elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="10505580" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">5</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-6613894 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="6613894" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h6 class="font-size-10 " style="text-align: center;">Training
                                            Courses</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-5f4934d5 exad-glass-effect-no exad-sticky-section-no"
                            data-id="5f4934d5" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-5bf742e9 elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="5bf742e9" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">6</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-2bc9aec5 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="2bc9aec5" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h5 class="font-size-15 " style="text-align: center;">Skills</h5></div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-538f57fa exad-glass-effect-no exad-sticky-section-no"
                            data-id="538f57fa" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-320c1cb3 elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="320c1cb3" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">7</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-4480699 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="4480699" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h6 class="font-size-15 " style="text-align: center;">Professional
                                            summary</h6></div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-cfb6ba0 exad-glass-effect-no exad-sticky-section-no"
                            data-id="cfb6ba0" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-26c098a4 elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="26c098a4" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">8</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-24af88b5 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="24af88b5" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h6 class="font-size-15 " style="text-align: center;">Languages</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div
                            class="elementor-column elementor-col-11 elementor-inner-column elementor-element elementor-element-5a1f101c exad-glass-effect-no exad-sticky-section-no"
                            data-id="5a1f101c" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div
                                    class="elementor-element elementor-element-42af9560 elementor-widget__width-initial exad-glass-effect-yes exad-sticky-section-no elementor-widget elementor-widget-heading"
                                    data-id="42af9560" data-element_type="widget"
                                    data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h4 class="elementor-heading-title elementor-size-default">9</h4></div>
                                </div>
                                <div
                                    class="elementor-element elementor-element-5486a7b0 exad-sticky-section-no exad-glass-effect-no elementor-widget elementor-widget-text-editor"
                                    data-id="5486a7b0" data-element_type="widget"
                                    data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <h6 class="font-size-15 " style="text-align: center;">Finalise</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\cv\resources\views/cv/steps_header.blade.php ENDPATH**/ ?>