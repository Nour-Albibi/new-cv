<?php

return [
    'Start Now'=>'ابدأ الآن',
    'Our Clients'=>'عملاؤنا'
];
